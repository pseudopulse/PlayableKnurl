# Playable Knurl
Ever wanted to play as a Titanic Knurl? No? Well now you can!

![screenshot of playable titanic knurl][def]

[def]: https://cdn.discordapp.com/attachments/959133036815978498/1067111725427601439/100050-screenshot.png "playable knurl"

# Changelog
## 1.0.1
- added the github link to the mod page
- become a real mod by doing a readme update